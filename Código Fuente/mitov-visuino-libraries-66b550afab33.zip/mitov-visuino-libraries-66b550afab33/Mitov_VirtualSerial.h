////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//     This software is supplied under the terms of a license agreement or    //
//     nondisclosure agreement with Mitov Software and may not be copied      //
//     or disclosed except in accordance with the terms of that agreement.    //
//         Copyright(c) 2002-2020 Mitov Software. All Rights Reserved.        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#pragma once

#include <Mitov.h>

namespace Mitov
{
//---------------------------------------------------------------------------
namespace TArduinoBluetoothUartType
{
	enum TArduinoBluetoothUartType { Nordic, HC08 };
}
//---------------------------------------------------------------------------
	template <
		typename T_OWNER, T_OWNER &C_OWNER,
		typename T_OutputPin
	> class VirtualSerialData :
		public T_OutputPin
	{
	public:
		_V_PIN_( OutputPin )

	public:
		inline void InputPin_o_Receive( void *_Data )
		{
			C_OWNER.DataReceived( _Data );
		}

	public:
		inline void SendData( uint32_t ALength, uint8_t *AData )
		{
			if( T_OutputPin::GetPinIsConnected() )
				T_OutputPin::SetPinValue( Mitov::TDataBlock( ALength, AData ) );
		}

/*
		inline void SendData( Mitov::TDataBlock & AValue )
		{
			T_OutputPin::SetPinValue( AValue );
		}
*/
	};
//---------------------------------------------------------------------------
/*
	class VirtualSerialStream : public Stream
	{
	public:
		inline Stream &GetStream()
		{ 
			return *this; 
		}

	public:
	    size_t write(uint8_t byte) override
		{
		}

	public:
		int available() override
		{
		}

		int peek() override
		{
		}

		int read() override
		{
		}

		void flush()
#ifndef VISUINO_K210
			override
#endif // !VISUINO_K210
		{
		}

	};
//---------------------------------------------------------------------------
	class VirtualSerialNoStream
	{
	public:
		virtual size_t write( uint8_t AChar )
		{
		}

	public:
		inline Stream GetStream()
		{ 
			return VirtualStreamOut<T_SELF, T_CONFIG>( this, AConfig, (VirtualSerialNoStream::TCallback) &write<T_CONFIG> );
		}

	};
*/
//---------------------------------------------------------------------------
	template <
		typename T_BufferSize,
		typename T_Data_SendData,
		typename T_Enabled,
		typename T_OutputPin
	> class VirtualSerial :
		public T_BufferSize,
		public T_Enabled,
		public T_OutputPin
	{
	public:
		_V_PIN_( OutputPin )

	public:
		_V_PROP_( Enabled )
		_V_PROP_( BufferSize )

	protected:
	    size_t write(uint8_t byte)
		{
			if( Enabled() )
				T_Data_SendData::ChainCall( 1, &byte );
		}

	    static size_t write_Impl( VirtualSerial * AInstance, uint8_t AByte )
		{
			return AInstance->write( AByte );
		}

	public:
		inline void DataReceived( void * _Data )
		{
			if( T_OutputPin::GetPinIsConnected() )
				if( Enabled() )
				{
					Mitov::TDataBlock *ADataBlock = ( Mitov::TDataBlock * )_Data;
					T_OutputPin::SetPinValue( *ADataBlock );
				}
			
		}

	public:
		inline VirtualStreamOut<VirtualSerial> GetStream()
		{ 
			return VirtualStreamOut<VirtualSerial>( this, (typename VirtualStreamOut<VirtualSerial>::TCallback) &VirtualSerial::write_Impl );
		}

	public:
		template<typename T> void Print( T AValue )
		{
			if( Enabled() )
				GetStream().println( AValue );

		}

		void Print( Mitov::String AValue )
		{
			if( Enabled() )
				GetStream().println( AValue );

		}

		void Print( char *AValue )
		{
			if( Enabled() )
				GetStream().println( AValue );

		}

		void PrintChar( char AValue )
		{
			if( Enabled() )
				GetStream().print( AValue );

		}

		void Write( uint8_t *AData, uint32_t ASize )
		{
			if( Enabled() )
				GetStream().write( AData, ASize );
		}

	};
//---------------------------------------------------------------------------
	template <
		typename T_BufferSize,
		typename T_Data_SendData,
		typename T_Enabled,
		typename T_OutputPin
	> class VirtualSerial_Stream :
		public Buffered_Stream,
		public T_BufferSize,
		public T_Enabled,
		public T_OutputPin
	{
		typedef Buffered_Stream inherited;

	public:
		_V_PIN_( OutputPin )

	public:
		_V_PROP_( Enabled )
		_V_PROP_( BufferSize )

	public:
	    virtual size_t write( uint8_t AByte ) override
		{
			if( Enabled() )
				T_Data_SendData::ChainCall( 1, &AByte );
		}

	public:
		inline void DataReceived( void * _Data )
		{
			if( ! Enabled().GetValue() )
				return;

			Mitov::TDataBlock *ADataBlock = ( Mitov::TDataBlock * )_Data;
			SendToBuffer( ADataBlock->Data, ADataBlock->Size, BufferSize().GetValue() );
			T_OutputPin::SetPinValue( *ADataBlock );			
		}

	public:
		template<typename T> void Print( T AValue )
		{
			if( Enabled() )
				println( AValue );

		}

		inline void Print( Mitov::String AValue )
		{
			if( Enabled() )
				println( AValue );

		}

		inline void Print( char *AValue )
		{
			if( Enabled() )
				println( AValue );

		}

		inline void PrintChar( char AValue )
		{
			if( Enabled() )
				print( AValue );

		}

		inline void Write( uint8_t *AData, uint32_t ASize )
		{
			if( Enabled() )
				write( AData, ASize );

		}

	};
//---------------------------------------------------------------------------
}

